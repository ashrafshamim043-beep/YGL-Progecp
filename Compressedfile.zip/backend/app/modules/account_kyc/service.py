"""
AccountKYCService -- orchestrates Initial Account KYC submission:
1. Requires mobile verification already complete (this service does not
   send/verify OTP itself -- that is a separate, not-yet-decided SMS
   vendor integration, out of this module's scope).
2. Links the member to a KYCIdentity via the document number, enforcing
   the max-3-Member-IDs-per-identity rule (kyc_identity/core.py).
3. On success, activates the member via MemberActivationPort.
   On MaxMemberIdsExceededError, the submission is rejected outright --
   the member is NOT activated, and this is surfaced as a clear error,
   never silently downgraded to a pending/manual-review state (per
   Business Decision: "কোনোভাবেই তৈরি করা যাবে না").
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional

from app.modules.account_kyc.core import (
    AccountKYCRecord, AccountKYCRepository, MemberActivationPort, MobileNotVerifiedError,
    AccountKYCStatus,
)
from app.modules.kyc_identity.core import (
    KYCIdentityRepository, DocumentType, link_member_to_identity,
    MaxMemberIdsExceededError, InvalidDocumentTypeError,
)


@dataclass
class AccountKYCResult:
    record: AccountKYCRecord
    member_activated: bool


class AccountKYCService:
    def __init__(
        self,
        account_kyc_repo: AccountKYCRepository,
        kyc_identity_repo: KYCIdentityRepository,
        member_activation: MemberActivationPort,
    ):
        self.account_kyc_repo = account_kyc_repo
        self.kyc_identity_repo = kyc_identity_repo
        self.member_activation = member_activation

    def submit(
        self, member_id: str, document_type: str, raw_document_number: str,
        document_image_reference: str, mobile_number: str, mobile_otp_verified: bool,
    ) -> AccountKYCResult:
        if not mobile_otp_verified:
            raise MobileNotVerifiedError(
                f"Mobile number '{mobile_number}' must be OTP-verified before Account KYC can be submitted."
            )

        # Raises MaxMemberIdsExceededError / InvalidDocumentTypeError
        # unmodified -- this service never catches or reinterprets those,
        # per the Business Decision's hard "never bypassed" directive.
        identity = link_member_to_identity(
            self.kyc_identity_repo, member_id, document_type, raw_document_number, mobile_number,
        )

        # CONFIRMED status flow: SUBMITTED -> VERIFIED (Y.G.L's own defined
        # workflow, NEVER presented as government-database verification).
        record = AccountKYCRecord(
            id=str(uuid.uuid4()), member_id=member_id, kyc_identity_id=identity.id,
            document_type=document_type, document_image_reference=document_image_reference,
            mobile_number=mobile_number, mobile_otp_verified=True,
            status=AccountKYCStatus.INITIAL_KYC_VERIFIED,
        )
        self.account_kyc_repo.save(record)

        activated = self.member_activation.activate_member(member_id)
        return AccountKYCResult(record=record, member_activated=activated)
