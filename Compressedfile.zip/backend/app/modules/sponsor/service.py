"""
SponsorService -- orchestrates initial placement and re-sponsorship,
delegating ALL tree-validation logic (self-sponsorship, circular-reference,
duplicate-placement, invalid-sponsor) to the frozen Commission Engine's
GenealogyEngine via GenealogyFacade. This service NEVER re-implements any
of that validation itself -- it only:
  1. Gathers the data GenealogyFacade needs (member directory + placement
     history) from its own repositories,
  2. Calls the facade,
  3. Persists whatever the facade/Engine returned,
  4. Translates the Engine's DuplicatePlacementFiledForReview into this
     module's own PlacementReviewRecord being saved.
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import List, Optional, Tuple

from app.services.commission_service.genealogy_facade import (
    GenealogyFacade, SponsorPlacement,
    CircularReferenceError, SelfSponsorshipError, InvalidSponsorError,
    MemberNotFoundError, DuplicatePlacementFiledForReview,
)
from app.modules.sponsor.core import (
    SponsorPlacementRecord, PlacementReviewRecord,
    SponsorPlacementRepository, PlacementReviewRepository,
    SponsorNotEligibleError,
)


@dataclass
class PlacementResult:
    placement: Optional[SponsorPlacementRecord]
    filed_for_review: bool
    review_id: Optional[str] = None


class SponsorService:
    def __init__(
        self,
        placement_repo: SponsorPlacementRepository,
        review_repo: PlacementReviewRepository,
        member_directory_provider,  # callable() -> List[Tuple[member_id, role, account_status]]
    ):
        self.placement_repo = placement_repo
        self.review_repo = review_repo
        self.member_directory_provider = member_directory_provider

    def _build_facade(self) -> GenealogyFacade:
        directory_entries = self.member_directory_provider()
        existing = self._to_engine_placements(self.placement_repo.list_all())
        return GenealogyFacade(directory_entries, existing)

    @staticmethod
    def _to_engine_placements(records: List[SponsorPlacementRecord]) -> List[SponsorPlacement]:
        return [
            SponsorPlacement(
                placement_id=r.placement_id, member_id=r.member_id, sponsor_id=r.sponsor_id,
                effective_from=r.effective_from, effective_to=r.effective_to,
                placement_type=r.placement_type, placement_reason=r.placement_reason,
                created_by=r.created_by, created_at=r.created_at,
            )
            for r in records
        ]

    @staticmethod
    def _from_engine_placement(p: SponsorPlacement) -> SponsorPlacementRecord:
        return SponsorPlacementRecord(
            placement_id=p.placement_id, member_id=p.member_id, sponsor_id=p.sponsor_id,
            effective_from=p.effective_from, effective_to=p.effective_to,
            placement_type=p.placement_type.value if hasattr(p.placement_type, "value") else p.placement_type,
            placement_reason=p.placement_reason, created_by=p.created_by, created_at=p.created_at,
        )

    # -- Initial placement ----------------------------------------------

    def place_member(self, member_id: str, sponsor_id: Optional[str],
                      created_by: str = "SELF") -> PlacementResult:
        """
        Raises (unmodified, re-exported from the frozen Engine):
          - SelfSponsorshipError, CircularReferenceError, InvalidSponsorError,
            MemberNotFoundError -- rejected outright, nothing persisted.
        Returns PlacementResult(filed_for_review=True) instead of raising,
        for the duplicate-placement case -- per Decision #4 (route to
        review queue, not reject), a review record is saved and no
        exception escapes this method for that specific case.
        """
        now = datetime.now(timezone.utc)
        facade = self._build_facade()
        try:
            engine_placement = facade.place_member(member_id, sponsor_id, now, created_by)
        except DuplicatePlacementFiledForReview:
            review = PlacementReviewRecord(
                review_id=str(uuid.uuid4()), member_id=member_id,
                attempted_sponsor_id=sponsor_id or "", status="PENDING", attempted_at=now,
            )
            self.review_repo.save(review)
            return PlacementResult(placement=None, filed_for_review=True, review_id=review.review_id)

        record = self._from_engine_placement(engine_placement)
        self.placement_repo.save(record)
        return PlacementResult(placement=record, filed_for_review=False)

    # -- Re-sponsorship (staff-approved sponsor change) ----------------------

    def re_sponsor(self, member_id: str, new_sponsor_id: str, approved_by: str,
                    reason: str, review_id: Optional[str] = None) -> PlacementResult:
        """Staff-approved sponsor change -- per Decision, this always
        requires an admin actor (approved_by) and a reason; there is no
        self-service re-sponsorship path in this service."""
        now = datetime.now(timezone.utc)
        facade = self._build_facade()
        engine_placement = facade.re_sponsor(member_id, new_sponsor_id, now, approved_by, reason, review_id)
        record = self._from_engine_placement(engine_placement)
        self.placement_repo.save(record)

        if review_id is not None:
            review = self.review_repo.get_by_id(review_id)
            if review is not None:
                review.status = "APPROVED"
                review.reviewed_by = approved_by
                review.reviewed_at = now
                review.decision_reason = reason
                self.review_repo.save(review)

        return PlacementResult(placement=record, filed_for_review=False)

    # -- Review queue -----------------------------------------------------

    def list_pending_reviews(self) -> List[PlacementReviewRecord]:
        return self.review_repo.list_pending()

    def reject_review(self, review_id: str, rejected_by: str, reason: str) -> PlacementReviewRecord:
        review = self.review_repo.get_by_id(review_id)
        if review is None:
            raise ValueError(f"No review found with id {review_id}")
        review.status = "REJECTED"
        review.reviewed_by = rejected_by
        review.reviewed_at = datetime.now(timezone.utc)
        review.decision_reason = reason
        self.review_repo.save(review)
        return review
