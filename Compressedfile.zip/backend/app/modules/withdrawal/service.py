"""
WithdrawalService -- the Commission Earn / Commission Withdrawal boundary
(Business Decision Section 2). Commission Earn is untouched -- it is
entirely the frozen Commission Engine's output, persisted by
commission_service's DBImmutableLedger, never re-implemented here.
Withdrawal is a REQUEST subject to two independent gates:
  1. Withdrawal KYC approved (this module's own status record)
  2. Sufficient available balance (queried via an injected callable --
     never a direct commission_engine/commission_service import here)
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from decimal import Decimal
from typing import Callable

from app.modules.withdrawal.core import (
    WithdrawalKYCStatus, WithdrawalKYCStatusValue, WithdrawalRequest,
    WithdrawalKYCStatusRepository, WithdrawalRequestRepository,
    WithdrawalKYCRequiredError, InsufficientBalanceError, InvalidWithdrawalAmountError,
)

BalanceProvider = Callable[[str], Decimal]  # member_id -> available balance


class WithdrawalService:
    def __init__(
        self,
        kyc_status_repo: WithdrawalKYCStatusRepository,
        request_repo: WithdrawalRequestRepository,
        balance_provider: BalanceProvider,
    ):
        self.kyc_status_repo = kyc_status_repo
        self.request_repo = request_repo
        self.balance_provider = balance_provider

    def mark_withdrawal_kyc_approved(self, member_id: str) -> WithdrawalKYCStatus:
        """
        Called by whichever flow eventually completes Withdrawal KYC
        (deliberately NOT decided/wired in this module -- see this
        module's core.py docstring; this method is the clean seam a
        future decision plugs into, without this module needing to change).
        """
        status = WithdrawalKYCStatus(
            member_id=member_id, status=WithdrawalKYCStatusValue.APPROVED,
            approved_at=datetime.now(timezone.utc),
        )
        self.kyc_status_repo.save(status)
        return status

    def request_withdrawal(self, member_id: str, amount: Decimal) -> WithdrawalRequest:
        """
        Raises WithdrawalKYCRequiredError if Withdrawal KYC is not
        APPROVED (regardless of ledger balance -- checked FIRST,
        deliberately, so a non-zero balance never masks a missing KYC
        requirement). Raises InsufficientBalanceError if the balance,
        AFTER the KYC check passes, is less than the requested amount.
        """
        if amount <= 0:
            raise InvalidWithdrawalAmountError(f"Withdrawal amount must be positive, got {amount}.")

        kyc_status = self.kyc_status_repo.get_for_member(member_id)
        if kyc_status.status != WithdrawalKYCStatusValue.APPROVED:
            raise WithdrawalKYCRequiredError(
                f"Member '{member_id}' has not completed Withdrawal KYC "
                f"(current status: {kyc_status.status}). Commission may be earned "
                f"and remain in the ledger, but cannot be withdrawn until Withdrawal "
                f"KYC is approved."
            )

        available = self.balance_provider(member_id)
        if available < amount:
            raise InsufficientBalanceError(available=available, requested=amount)

        request = WithdrawalRequest(
            id=str(uuid.uuid4()), member_id=member_id, amount=amount,
            status="PENDING", created_at=datetime.now(timezone.utc),
        )
        self.request_repo.save(request)
        return request
