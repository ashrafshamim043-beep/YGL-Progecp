"""
KYCIdentity core domain logic -- the "Master Identity" that links up to 3
Member IDs belonging to the same real person, per Business Decision
(Y.G.L Phase 8, "3-Account Policy").

Pure Python, zero external dependencies. Same abstract-interface +
in-memory-implementation pattern as every other module in this system.

Identity-matching design (flagged, explicit -- not a silent assumption):
A KYCIdentity is keyed by a NORMALIZED document number (NID or Birth
Registration Number). The first Member to submit a given document number
creates a new KYCIdentity. A second/third Member submitting the SAME
document number is linked to that SAME KYCIdentity (up to 3 total). A
fourth attempt with the same document number is rejected outright. This
is the most direct, unambiguous technical reading of "same KYC Identity
-> up to 3 Member IDs, a 4th is never created" -- but it IS a technical
mapping of the business rule, not itself dictated word-for-word by the
Business Owner's message, so it is called out here explicitly.
"""
from __future__ import annotations

import re
import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, List, Optional


MAX_MEMBER_IDS_PER_IDENTITY = 3


class DocumentType:
    NID = "NID"
    BIRTH_REGISTRATION = "BIRTH_REGISTRATION"

    ALL = {NID, BIRTH_REGISTRATION}


def normalize_document_number(document_type: str, raw_number: str) -> str:
    """Strips whitespace/dashes and upper-cases -- so '123-456 789' and
    '123456789' are recognized as the SAME document (a realistic input-
    variance concern for a Bangladesh NID/Birth-Reg number typed by hand
    in different formats)."""
    if not raw_number:
        raise ValueError("document number must not be empty.")
    return re.sub(r"[\s\-]", "", raw_number).upper()


# ---------------------------------------------------------------------------
# Domain records
# ---------------------------------------------------------------------------

@dataclass
class KYCIdentity:
    id: str
    document_type: str  # NID / BIRTH_REGISTRATION
    normalized_document_number: str
    mobile_number: str
    linked_member_ids: List[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class MaxMemberIdsExceededError(Exception):
    """Raised when a 4th (or further) Member ID is attempted under the
    same KYCIdentity -- per Business Decision, this limit is hard,
    never configurable per-identity, never bypassed."""
    def __init__(self, identity_id: str):
        self.identity_id = identity_id
        super().__init__(
            f"KYCIdentity '{identity_id}' already has {MAX_MEMBER_IDS_PER_IDENTITY} "
            f"linked Member IDs -- a 4th cannot be created under the same identity."
        )


class InvalidDocumentTypeError(Exception):
    pass


# ---------------------------------------------------------------------------
# Repository interface + in-memory implementation
# ---------------------------------------------------------------------------

class KYCIdentityRepository(ABC):
    @abstractmethod
    def get_by_document(self, document_type: str, normalized_document_number: str) -> Optional[KYCIdentity]:
        raise NotImplementedError

    @abstractmethod
    def get_by_document_locked(self, document_type: str, normalized_document_number: str) -> Optional[KYCIdentity]:
        """
        CONCURRENCY-CRITICAL: same lookup as get_by_document(), but the
        DB-backed implementation MUST acquire a row-level lock (e.g.
        SELECT ... FOR UPDATE) when a matching row exists, so that two
        concurrent callers attempting to link a 3rd/4th member to the
        SAME identity are serialized -- the second caller blocks until
        the first's transaction commits, then sees the up-to-date
        linked_member_ids count. In-memory implementations (single-
        threaded tests) may simply delegate to get_by_document().
        link_member_to_identity() below always calls this method, never
        the unlocked one, specifically so this guarantee is uniform
        across every caller.
        """
        raise NotImplementedError

    @abstractmethod
    def get_by_id(self, identity_id: str) -> Optional[KYCIdentity]:
        raise NotImplementedError

    @abstractmethod
    def save(self, identity: KYCIdentity) -> None:
        raise NotImplementedError


class InMemoryKYCIdentityRepository(KYCIdentityRepository):
    def __init__(self):
        self._by_id: Dict[str, KYCIdentity] = {}

    def get_by_document(self, document_type: str, normalized_document_number: str) -> Optional[KYCIdentity]:
        for identity in self._by_id.values():
            if (identity.document_type == document_type
                    and identity.normalized_document_number == normalized_document_number):
                return identity
        return None

    def get_by_document_locked(self, document_type: str, normalized_document_number: str) -> Optional[KYCIdentity]:
        # Single-threaded in-memory test double -- no real lock needed,
        # but implements the same interface so link_member_to_identity()
        # can call it uniformly regardless of backing store.
        return self.get_by_document(document_type, normalized_document_number)

    def get_by_id(self, identity_id: str) -> Optional[KYCIdentity]:
        return self._by_id.get(identity_id)

    def save(self, identity: KYCIdentity) -> None:
        self._by_id[identity.id] = identity


# ---------------------------------------------------------------------------
# Domain service function (pure logic, no I/O beyond the repository)
# ---------------------------------------------------------------------------

def link_member_to_identity(
    repo: KYCIdentityRepository, member_id: str, document_type: str, raw_document_number: str,
    mobile_number: str,
) -> KYCIdentity:
    """
    Finds-or-creates the KYCIdentity for this document, links member_id to
    it, enforcing the max-3 rule. Idempotent for the SAME member_id being
    linked again (a re-submission does not double-count).

    CONCURRENCY: always reads via get_by_document_locked() (never the
    unlocked get_by_document()) -- for a DB-backed repository called
    inside a real transaction, this makes the max-3 check safe against
    two concurrent 3rd/4th-ID submissions for the same identity (see
    get_by_document_locked()'s docstring). This function itself remains
    pure Python and does not manage transactions -- the CALLER (service
    layer / router) is responsible for wrapping this call in one DB
    transaction so the lock is actually held for its duration.
    """
    if document_type not in DocumentType.ALL:
        raise InvalidDocumentTypeError(f"Unrecognized document_type: {document_type!r}")

    normalized = normalize_document_number(document_type, raw_document_number)
    identity = repo.get_by_document_locked(document_type, normalized)

    if identity is None:
        identity = KYCIdentity(
            id=str(uuid.uuid4()), document_type=document_type,
            normalized_document_number=normalized, mobile_number=mobile_number,
            linked_member_ids=[member_id],
        )
        repo.save(identity)
        return identity

    if member_id in identity.linked_member_ids:
        return identity  # idempotent re-submission, not a new link

    if len(identity.linked_member_ids) >= MAX_MEMBER_IDS_PER_IDENTITY:
        raise MaxMemberIdsExceededError(identity.id)

    identity.linked_member_ids.append(member_id)
    repo.save(identity)
    return identity
