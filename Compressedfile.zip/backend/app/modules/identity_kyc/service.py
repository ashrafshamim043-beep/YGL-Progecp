"""
IdentityKYCService -- orchestrates Account KYC completion: mobile
verification check, Master-Identity lookup-or-creation, the 3-Member-ID
cap enforcement, AccountKYCRecord persistence, and finally triggering
Member activation via MemberService.activate_via_account_kyc().

Mobile verification itself (OTP send/verify) is NOT implemented here --
per this project's established pattern (e.g. Sumsub's live API calls),
external-service integration is out of scope until a vendor/approach is
confirmed. This service accepts an already-verified boolean
(mobile_verified) from the caller, exactly as the existing kyc module
accepts pre-verified webhook signatures rather than doing HTTP calls
itself.
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional

from app.modules.identity_kyc.core import (
    MasterKYCIdentity, MemberIdentityLink, AccountKYCRecord,
    MasterKYCIdentityRepository, MemberIdentityLinkRepository, AccountKYCRepository,
    DocumentType, MAX_MEMBER_IDS_PER_IDENTITY,
    MobileNotVerifiedError, InvalidDocumentTypeError,
    DuplicateAccountKYCError, MaxMemberIdentityLimitError,
)
from app.modules.member.service import MemberService


@dataclass
class AccountKYCResult:
    record: AccountKYCRecord
    master_identity_id: str
    member_ids_linked_to_identity: int  # count AFTER this registration, for visibility/audit


class IdentityKYCService:
    def __init__(
        self,
        master_identity_repo: MasterKYCIdentityRepository,
        link_repo: MemberIdentityLinkRepository,
        account_kyc_repo: AccountKYCRepository,
        member_service: MemberService,
    ):
        self.master_identity_repo = master_identity_repo
        self.link_repo = link_repo
        self.account_kyc_repo = account_kyc_repo
        self.member_service = member_service

    def complete_account_kyc(
        self, member_id: str, mobile_number: str, mobile_verified: bool,
        document_type: str, document_number: str,
    ) -> AccountKYCResult:
        """
        Raises MobileNotVerifiedError, InvalidDocumentTypeError,
        DuplicateAccountKYCError, or MaxMemberIdentityLimitError -- any of
        these leaves NOTHING persisted and does NOT activate the member.
        On success: persists MasterKYCIdentity (new or existing),
        MemberIdentityLink, AccountKYCRecord, and activates the member --
        all attempted only after every validation has passed (no partial
        state on the happy path either, since activation is the LAST step).
        """
        if not mobile_verified:
            raise MobileNotVerifiedError(f"Mobile number '{mobile_number}' is not verified.")
        if document_type not in DocumentType.VALID:
            raise InvalidDocumentTypeError(f"Unrecognized document_type: {document_type!r}")
        if self.account_kyc_repo.get_for_member(member_id) is not None:
            raise DuplicateAccountKYCError(f"Member '{member_id}' has already completed Account KYC.")

        now = datetime.now(timezone.utc)
        identity = self.master_identity_repo.get_by_document(document_type, document_number)
        if identity is None:
            identity = MasterKYCIdentity(
                id=str(uuid.uuid4()), document_type=document_type,
                document_number=document_number, created_at=now,
            )
            self.master_identity_repo.save(identity)

        existing_links = self.link_repo.list_for_identity(identity.id)
        if len(existing_links) >= MAX_MEMBER_IDS_PER_IDENTITY:
            raise MaxMemberIdentityLimitError(identity.id)

        link = MemberIdentityLink(
            id=str(uuid.uuid4()), member_id=member_id, master_identity_id=identity.id, created_at=now,
        )
        self.link_repo.save(link)

        record = AccountKYCRecord(
            id=str(uuid.uuid4()), member_id=member_id, master_identity_id=identity.id,
            mobile_number=mobile_number, document_type=document_type,
            document_number=document_number, created_at=now,
        )
        self.account_kyc_repo.save(record)

        # Activation is the LAST step, only after everything else succeeded.
        self.member_service.activate_via_account_kyc(member_id, verified_by="ACCOUNT_KYC_SERVICE")

        return AccountKYCResult(
            record=record, master_identity_id=identity.id,
            member_ids_linked_to_identity=len(existing_links) + 1,
        )

    def get_linked_member_ids(self, master_identity_id: str) -> list:
        """Used by duplicate/fraud screening and Withdrawal-KYC's
        cross-Member-ID checks (per Business Decision Section 6)."""
        return [link.member_id for link in self.link_repo.list_for_identity(master_identity_id)]
