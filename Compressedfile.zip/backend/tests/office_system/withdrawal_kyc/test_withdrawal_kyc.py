"""
Withdrawal KYC eligibility test suite -- proves Commission Withdrawal is
blocked until the EXISTING kyc/ module (Sumsub-based, Identity+NID+Face+
Liveness combined -- the "Withdrawal KYC" tier per Business Decision)
reaches APPROVED. Uses the REAL YGLKYCService/SumsubAdapter/state machine
(the same ones with 24 passing tests already) -- no new KYC logic is
introduced or duplicated here.
"""
import hashlib
import hmac
import json
import unittest

from app.modules.kyc.core import (
    InMemoryKYCVerificationRepository, InMemoryKYCStateTransitionRepository,
    InMemoryAuditLogWriter, InMemoryMemberActivationPort, KYCState,
)
from app.modules.kyc.service import YGLKYCService
from app.modules.kyc.sumsub_adapter import SumsubAdapter
from app.modules.withdrawal_kyc.core import (
    is_withdrawal_eligible, require_withdrawal_eligible, WithdrawalKYCRequiredError,
)

WEBHOOK_SECRET = "withdrawal-test-secret"


def sign(payload: bytes) -> str:
    return hmac.new(WEBHOOK_SECRET.encode(), payload, hashlib.sha256).hexdigest()


def build_kyc_service():
    provider = SumsubAdapter(webhook_secret=WEBHOOK_SECRET)
    verification_repo = InMemoryKYCVerificationRepository()
    kyc_service = YGLKYCService(
        provider, verification_repo, InMemoryKYCStateTransitionRepository(),
        InMemoryAuditLogWriter(), InMemoryMemberActivationPort(),
    )
    return kyc_service, verification_repo


class TestWithdrawalBlockedBeforeFullKyc(unittest.TestCase):
    def test_no_verification_at_all_blocks_withdrawal(self):
        kyc_service, verification_repo = build_kyc_service()
        self.assertFalse(is_withdrawal_eligible(verification_repo, "member-never-started-kyc"))
        with self.assertRaises(WithdrawalKYCRequiredError):
            require_withdrawal_eligible(verification_repo, "member-never-started-kyc")

    def test_pending_state_blocks_withdrawal(self):
        kyc_service, verification_repo = build_kyc_service()
        kyc_service.start_verification("member-1", "SUMSUB", "applicant-1")
        self.assertFalse(is_withdrawal_eligible(verification_repo, "member-1"))

    def test_in_progress_state_blocks_withdrawal(self):
        """Identity+NID submitted but Face/Liveness not yet completed --
        still blocked. This is the direct test of the Business Decision's
        Face/Liveness requirement: partial completion is not enough."""
        kyc_service, verification_repo = build_kyc_service()
        verification = kyc_service.start_verification("member-1", "SUMSUB", "applicant-1")
        kyc_service.submit_document(verification.id, "member-1")
        payload = json.dumps({
            "applicantId": "applicant-1", "type": "applicantReviewed",
            "reviewStatus": "pending", "reviewResult": {}, "createdAtMs": "2026-08-30 09:00:00.000",
        }).encode()
        kyc_service.process_webhook(payload, sign(payload))

        stored = verification_repo.get_active_for_member("member-1")
        self.assertEqual(stored.state, KYCState.VERIFICATION_IN_PROGRESS)
        self.assertFalse(is_withdrawal_eligible(verification_repo, "member-1"))
        with self.assertRaises(WithdrawalKYCRequiredError) as ctx:
            require_withdrawal_eligible(verification_repo, "member-1")
        self.assertIn("VERIFICATION_IN_PROGRESS", str(ctx.exception))

    def test_manual_review_state_blocks_withdrawal(self):
        kyc_service, verification_repo = build_kyc_service()
        verification = kyc_service.start_verification("member-1", "SUMSUB", "applicant-1")
        kyc_service.submit_document(verification.id, "member-1")
        in_progress_payload = json.dumps({
            "applicantId": "applicant-1", "type": "applicantReviewed",
            "reviewStatus": "pending", "reviewResult": {}, "createdAtMs": "2026-08-30 09:00:00.000",
        }).encode()
        kyc_service.process_webhook(in_progress_payload, sign(in_progress_payload))

        manual_review_payload = json.dumps({
            "applicantId": "applicant-1", "type": "applicantReviewed",
            "reviewStatus": "completed", "reviewResult": {"reviewAnswer": "RED", "reviewRejectType": "RETRY"},
            "createdAtMs": "2026-08-30 10:00:00.000",
        }).encode()
        kyc_service.process_webhook(manual_review_payload, sign(manual_review_payload))

        self.assertFalse(is_withdrawal_eligible(verification_repo, "member-1"))

    def test_rejected_state_blocks_withdrawal(self):
        kyc_service, verification_repo = build_kyc_service()
        verification = kyc_service.start_verification("member-1", "SUMSUB", "applicant-1")
        kyc_service.submit_document(verification.id, "member-1")
        in_progress_payload = json.dumps({
            "applicantId": "applicant-1", "type": "applicantReviewed",
            "reviewStatus": "pending", "reviewResult": {}, "createdAtMs": "2026-08-30 09:00:00.000",
        }).encode()
        kyc_service.process_webhook(in_progress_payload, sign(in_progress_payload))

        rejected_payload = json.dumps({
            "applicantId": "applicant-1", "type": "applicantReviewed",
            "reviewStatus": "completed", "reviewResult": {"reviewAnswer": "RED", "reviewRejectType": "FINAL"},
            "createdAtMs": "2026-08-30 10:00:00.000",
        }).encode()
        kyc_service.process_webhook(rejected_payload, sign(rejected_payload))

        self.assertFalse(is_withdrawal_eligible(verification_repo, "member-1"))


class TestWithdrawalAllowedAfterFullKyc(unittest.TestCase):
    def test_approved_state_allows_withdrawal(self):
        """Full Identity+NID+Face+Liveness (the complete Sumsub flow)
        reaching APPROVED -- the only state that unlocks withdrawal."""
        kyc_service, verification_repo = build_kyc_service()
        verification = kyc_service.start_verification("member-1", "SUMSUB", "applicant-1")
        kyc_service.submit_document(verification.id, "member-1")
        in_progress_payload = json.dumps({
            "applicantId": "applicant-1", "type": "applicantReviewed",
            "reviewStatus": "pending", "reviewResult": {}, "createdAtMs": "2026-08-30 09:00:00.000",
        }).encode()
        kyc_service.process_webhook(in_progress_payload, sign(in_progress_payload))

        approved_payload = json.dumps({
            "applicantId": "applicant-1", "type": "applicantReviewed",
            "reviewStatus": "completed", "reviewResult": {"reviewAnswer": "GREEN"},
            "createdAtMs": "2026-08-30 10:00:00.000",
        }).encode()
        kyc_service.process_webhook(approved_payload, sign(approved_payload))

        self.assertTrue(is_withdrawal_eligible(verification_repo, "member-1"))
        require_withdrawal_eligible(verification_repo, "member-1")  # must not raise


class TestEarnVsWithdrawDistinctionDoesNotBlockOtherMembers(unittest.TestCase):
    def test_one_members_missing_withdrawal_kyc_does_not_affect_another_member(self):
        kyc_service, verification_repo = build_kyc_service()
        v1 = kyc_service.start_verification("member-full-kyc", "SUMSUB", "applicant-1")
        kyc_service.submit_document(v1.id, "member-full-kyc")
        p1 = json.dumps({"applicantId": "applicant-1", "type": "applicantReviewed",
                          "reviewStatus": "pending", "reviewResult": {}, "createdAtMs": "2026-08-30 09:00:00.000"}).encode()
        kyc_service.process_webhook(p1, sign(p1))
        p2 = json.dumps({"applicantId": "applicant-1", "type": "applicantReviewed",
                          "reviewStatus": "completed", "reviewResult": {"reviewAnswer": "GREEN"},
                          "createdAtMs": "2026-08-30 10:00:00.000"}).encode()
        kyc_service.process_webhook(p2, sign(p2))

        kyc_service.start_verification("member-no-withdrawal-kyc", "SUMSUB", "applicant-2")

        self.assertTrue(is_withdrawal_eligible(verification_repo, "member-full-kyc"))
        self.assertFalse(is_withdrawal_eligible(verification_repo, "member-no-withdrawal-kyc"))


if __name__ == "__main__":
    unittest.main()
