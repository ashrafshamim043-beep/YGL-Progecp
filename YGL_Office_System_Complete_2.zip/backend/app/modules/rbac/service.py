"""
RBACService -- the "fine-grained service/endpoint permission check" layer.

Combines: (1) token verification, delegated entirely to the existing,
already-tested AuthService (Step 1) -- RBAC does not re-implement or alter
any token-verification logic; and (2) permission-checking against the
Business Owner's role matrix (core.py); and (3) audit-emission on both
allow and deny, via the reused AuditLogWriter interface.

HTTP-response note: PermissionDeniedError's str() includes the checked
permission name (useful for internal audit logs). When a FastAPI router is
wired to this service (a later step), the HTTP 403 response body sent to
the CLIENT must use a generic message ("Forbidden") -- not
str(exception) -- per the Business Owner's "sensitive information প্রকাশ
করবে না" directive. This module's job stops at raising the correct
exception type; response-body wording is the router's responsibility.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Optional

from app.modules.auth.service import AuthService
from app.modules.auth.core import AdminIdentity
from app.modules.auth.jwt_utils import InvalidTokenError
from app.modules.rbac.core import (
    RolePermissionRepository, AuditLogWriter,
    UnauthenticatedError, PermissionDeniedError,
)


class RBACService:
    def __init__(
        self,
        auth_service: AuthService,
        role_permission_repo: RolePermissionRepository,
        audit_log: AuditLogWriter,
    ):
        self.auth_service = auth_service
        self.role_permission_repo = role_permission_repo
        self.audit_log = audit_log

    def authorize(
        self, access_token: str, required_permission: str, resource: Optional[str] = None
    ) -> AdminIdentity:
        """
        The single entry point every protected endpoint calls (directly,
        or via a thin FastAPI-dependency wrapper added when routers are
        wired -- not part of this step's scope).

        Raises UnauthenticatedError (-> 401) for any missing/invalid/
        expired token -- this is EXACTLY AuthService's existing,
        already-tested InvalidTokenError, re-raised as RBAC's own 401-type
        so callers only need to know about RBAC's two exception types, not
        reach into Auth's internals.

        Raises PermissionDeniedError (-> 403) if the token is valid but the
        admin's role does not have `required_permission`.

        Emits exactly one audit event per call, describing the outcome,
        regardless of allow or deny.
        """
        try:
            identity = self.auth_service.get_identity_from_access_token(access_token)
        except InvalidTokenError as e:
            self.audit_log.write("RBAC_AUTHORIZATION_DENIED", {
                "actor_id": None,
                "permission_checked": required_permission,
                "action": "AUTHORIZE",
                "resource": resource,
                "result": "DENY",
                "reason": "UNAUTHENTICATED",
                "detail": str(e),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            })
            raise UnauthenticatedError(str(e))

        granted = self.role_permission_repo.get_permissions_for_role(identity.role_id)
        if required_permission not in granted:
            self.audit_log.write("RBAC_AUTHORIZATION_DENIED", {
                "actor_id": identity.admin_id,
                "permission_checked": required_permission,
                "action": "AUTHORIZE",
                "resource": resource,
                "result": "DENY",
                "reason": "INSUFFICIENT_PERMISSION",
                "role_id": identity.role_id,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            })
            raise PermissionDeniedError(identity.admin_id, required_permission)

        self.audit_log.write("RBAC_AUTHORIZATION_GRANTED", {
            "actor_id": identity.admin_id,
            "permission_checked": required_permission,
            "action": "AUTHORIZE",
            "resource": resource,
            "result": "ALLOW",
            "role_id": identity.role_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })
        return identity
