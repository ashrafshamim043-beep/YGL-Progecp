"""
Shared FastAPI dependency for permission-checking, used by any protected
router (KYC's manual-review endpoints today; future Member/Sponsor/
Commerce routers later, per the same pattern).
"""
from __future__ import annotations

from fastapi import Depends, Header, HTTPException
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.modules.auth.service import AuthService
from app.modules.auth.router import get_auth_service
from app.modules.audit.db_repository import SQLAlchemyAuditLogWriter
from app.modules.rbac.service import RBACService
from app.modules.rbac.db_repository import SQLAlchemyRolePermissionRepository
from app.modules.rbac.core import UnauthenticatedError, PermissionDeniedError


def get_rbac_service(
    db: Session = Depends(get_db),
    auth_service: AuthService = Depends(get_auth_service),
) -> RBACService:
    role_perm_repo = SQLAlchemyRolePermissionRepository(db)
    audit_log = SQLAlchemyAuditLogWriter(db)
    return RBACService(auth_service, role_perm_repo, audit_log)


def require_permission(permission_code: str):
    """
    Returns a FastAPI dependency that enforces `permission_code`. Usage in
    a router: `identity = Depends(require_permission(Permission.KYC_REVIEW))`.

    HTTP-response note (per Business Owner directive -- no sensitive
    information in the response body): 403 responses use a fixed generic
    message, never str(PermissionDeniedError) (which does name the
    checked permission -- fine for the audit log, not for the client).
    """
    def _dependency(
        authorization: str = Header(default=""),
        rbac_service: RBACService = Depends(get_rbac_service),
    ):
        if not authorization.startswith("Bearer "):
            raise HTTPException(status_code=401, detail="Missing or malformed Authorization header.")
        token = authorization[len("Bearer "):]
        try:
            return rbac_service.authorize(token, permission_code)
        except UnauthenticatedError:
            raise HTTPException(status_code=401, detail="Invalid or expired token.")
        except PermissionDeniedError:
            raise HTTPException(status_code=403, detail="Forbidden.")
    return _dependency
