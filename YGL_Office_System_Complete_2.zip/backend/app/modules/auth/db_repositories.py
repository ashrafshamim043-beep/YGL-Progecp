"""
SQLAlchemy-backed AdminRepository and RefreshTokenRepository -- production
adapters implementing the SAME interfaces (auth/core.py) that
InMemoryAdminRepository/InMemoryRefreshTokenRepository already implement
and that Step 1's 27 tests already prove correct. This file adds no new
authentication LOGIC -- it only persists/loads the same AdminAccount /
RefreshTokenRecord shapes.
"""
import uuid
from datetime import datetime
from typing import Optional

from sqlalchemy import String, DateTime, Integer, Boolean, ForeignKey, func, select
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, Session

from app.db.session import Base
from app.modules.identity.db_models import Admin as AdminRow
from app.modules.auth.core import (
    AdminAccount, RefreshTokenRecord, AdminRepository, RefreshTokenRepository,
)


class RefreshTokenRow(Base):
    __tablename__ = "refresh_tokens"

    token_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True)
    admin_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("admins.id"), nullable=False)
    issued_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    revoked: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    replaced_by_token_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True))


class SQLAlchemyAdminRepository(AdminRepository):
    def __init__(self, db: Session):
        self.db = db

    def _row_to_domain(self, row: Optional[AdminRow]) -> Optional[AdminAccount]:
        if row is None:
            return None
        return AdminAccount(
            id=str(row.id), email=row.email, password_hash=row.password_hash,
            role_id=str(row.role_id), status=row.status,
            mfa_secret=row.mfa_secret, mfa_enrolled=row.mfa_enrolled,
            failed_login_count=row.failed_login_count, locked_until=row.locked_until,
            created_at=row.created_at, last_login_at=row.last_login_at,
        )

    def get_by_email(self, email: str) -> Optional[AdminAccount]:
        row = self.db.execute(select(AdminRow).where(AdminRow.email == email)).scalar_one_or_none()
        return self._row_to_domain(row)

    def get_by_id(self, admin_id: str) -> Optional[AdminAccount]:
        row = self.db.get(AdminRow, uuid.UUID(admin_id))
        return self._row_to_domain(row)

    def save(self, account: AdminAccount) -> None:
        row = self.db.get(AdminRow, uuid.UUID(account.id))
        if row is None:
            raise ValueError(
                f"Admin '{account.id}' does not exist -- SQLAlchemyAdminRepository.save() "
                f"updates existing admins only; account CREATION is a separate, not-yet-built "
                f"Admin-provisioning flow (bootstrap procedure, per Architecture Blueprint v4 "
                f"Section T), intentionally not implemented here."
            )
        row.password_hash = account.password_hash
        row.status = account.status
        row.mfa_secret = account.mfa_secret
        row.mfa_enrolled = account.mfa_enrolled
        row.failed_login_count = account.failed_login_count
        row.locked_until = account.locked_until
        row.last_login_at = account.last_login_at
        self.db.flush()


class SQLAlchemyRefreshTokenRepository(RefreshTokenRepository):
    def __init__(self, db: Session):
        self.db = db

    def save(self, record: RefreshTokenRecord) -> None:
        row = self.db.get(RefreshTokenRow, uuid.UUID(record.token_id))
        if row is None:
            row = RefreshTokenRow(
                token_id=uuid.UUID(record.token_id), admin_id=uuid.UUID(record.admin_id),
                issued_at=record.issued_at, expires_at=record.expires_at, revoked=record.revoked,
                replaced_by_token_id=uuid.UUID(record.replaced_by_token_id) if record.replaced_by_token_id else None,
            )
            self.db.add(row)
        else:
            row.revoked = record.revoked
            row.replaced_by_token_id = uuid.UUID(record.replaced_by_token_id) if record.replaced_by_token_id else None
        self.db.flush()

    def get_by_id(self, token_id: str) -> Optional[RefreshTokenRecord]:
        row = self.db.get(RefreshTokenRow, uuid.UUID(token_id))
        if row is None:
            return None
        return RefreshTokenRecord(
            token_id=str(row.token_id), admin_id=str(row.admin_id),
            issued_at=row.issued_at, expires_at=row.expires_at, revoked=row.revoked,
            replaced_by_token_id=str(row.replaced_by_token_id) if row.replaced_by_token_id else None,
        )

    def revoke(self, token_id: str) -> None:
        row = self.db.get(RefreshTokenRow, uuid.UUID(token_id))
        if row is not None:
            row.revoked = True
            self.db.flush()

    def revoke_all_for_admin(self, admin_id: str) -> None:
        rows = self.db.execute(
            select(RefreshTokenRow).where(RefreshTokenRow.admin_id == uuid.UUID(admin_id))
        ).scalars().all()
        for row in rows:
            row.revoked = True
        self.db.flush()
