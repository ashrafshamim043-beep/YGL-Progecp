"""
AuthService -- orchestrates Admin login, MFA, and refresh-token flows.

Explicit scope boundary (per this step's authorization): this service
produces an AdminIdentity + JWT access token on successful auth. It does
NOT implement RBAC permission-checking or audit-log persistence -- those
are separate, later steps. It exposes admin_id/role_id in the JWT payload
specifically so a future RBAC/audit layer can consume them without this
service needing to change.
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Optional

from app.modules.auth.core import (
    AdminAccount, AdminIdentity, RefreshTokenRecord,
    AdminRepository, RefreshTokenRepository,
    InvalidCredentialsError, AccountLockedError, AccountDisabledError,
    MfaRequiredError, InvalidMfaCodeError, MfaNotEnrolledError,
    RefreshTokenInvalidError,
)
from app.modules.auth.password_hashing import PasswordHasher, InvalidHashFormatError
from app.modules.auth.totp import generate_secret, generate_totp, verify_totp
from app.modules.auth.jwt_utils import encode as jwt_encode, decode as jwt_decode, InvalidTokenError

MFA_CHALLENGE_TTL_SECONDS = 5 * 60  # short-lived on purpose -- must complete MFA promptly
MFA_CHALLENGE_PURPOSE = "mfa_challenge"


@dataclass
class LoginResult:
    identity: AdminIdentity
    access_token: str
    refresh_token_id: str


@dataclass
class AuthConfig:
    """
    All values here are CONFIGURATION, sourced from app.core.config.settings
    in the real deployment (never hard-coded, never committed as a real
    secret). Session-TTL-related business questions ("how long should an
    inactive admin stay logged in?") are flagged as BUSINESS OWNER DECISION
    in the accompanying report -- the numeric defaults below are technical
    placeholders pending that confirmation, not a business decision made
    by this code.
    """
    jwt_secret: str
    access_token_ttl_seconds: int = 20 * 60          # mirrors config.py's existing default (20 min)
    refresh_token_ttl_seconds: int = 14 * 24 * 60 * 60  # mirrors config.py's existing default (14 days)
    login_failure_threshold: int = 3                  # mirrors config.py's admin-specific default
    lockout_duration_seconds: int = 30 * 60


class AuthService:
    def __init__(
        self,
        admin_repo: AdminRepository,
        refresh_token_repo: RefreshTokenRepository,
        config: AuthConfig,
        password_hasher: Optional[PasswordHasher] = None,
    ):
        self.admin_repo = admin_repo
        self.refresh_token_repo = refresh_token_repo
        self.config = config
        self.password_hasher = password_hasher or PasswordHasher()

    # -- Login ----------------------------------------------------------

    def login(self, email: str, password: str) -> LoginResult:
        """
        Raises InvalidCredentialsError (unknown email OR wrong password --
        deliberately indistinguishable), AccountDisabledError,
        AccountLockedError, or MfaRequiredError (password correct, but a
        TOTP challenge must be completed via verify_mfa() next -- no
        tokens are issued at this point).
        """
        account = self.admin_repo.get_by_email(email)
        if account is None:
            # Deliberately perform a dummy hash-verify against a fixed,
            # never-matching hash so that "unknown email" and "wrong
            # password" take statistically similar time -- reduces
            # email-enumeration-via-timing risk.
            self.password_hasher.verify_password(password, self.password_hasher.hash_password("dummy"))
            raise InvalidCredentialsError("Invalid email or password.")

        if account.status != "ACTIVE":
            raise AccountDisabledError(f"Account '{email}' is not active.")

        now = datetime.now(timezone.utc)
        if account.locked_until is not None and account.locked_until > now:
            raise AccountLockedError(account.locked_until)

        try:
            password_ok = self.password_hasher.verify_password(password, account.password_hash)
        except InvalidHashFormatError:
            # A corrupted stored hash must never be treated as "any
            # password works" -- fail closed.
            password_ok = False

        if not password_ok:
            self._register_failed_attempt(account)
            raise InvalidCredentialsError("Invalid email or password.")

        # Correct password -- reset failure tracking regardless of MFA outcome.
        account.failed_login_count = 0
        account.locked_until = None

        if account.mfa_enrolled:
            self.admin_repo.save(account)
            challenge_token = jwt_encode(
                {"admin_id": account.id, "purpose": MFA_CHALLENGE_PURPOSE},
                self.config.jwt_secret, expires_in_seconds=MFA_CHALLENGE_TTL_SECONDS,
            )
            raise MfaRequiredError(account.id, challenge_token)

        account.last_login_at = now
        self.admin_repo.save(account)
        return self._issue_tokens(account)

    def _register_failed_attempt(self, account: AdminAccount) -> None:
        account.failed_login_count += 1
        if account.failed_login_count >= self.config.login_failure_threshold:
            account.locked_until = datetime.now(timezone.utc) + timedelta(
                seconds=self.config.lockout_duration_seconds
            )
        self.admin_repo.save(account)

    # -- MFA --------------------------------------------------------------

    def verify_mfa(self, mfa_challenge_token: str, totp_code: str) -> LoginResult:
        """Completes a login that was paused by MfaRequiredError."""
        try:
            payload = jwt_decode(mfa_challenge_token, self.config.jwt_secret)
        except InvalidTokenError as e:
            raise InvalidMfaCodeError(f"Invalid or expired MFA challenge: {e}")
        if payload.get("purpose") != MFA_CHALLENGE_PURPOSE:
            raise InvalidMfaCodeError("Token is not a valid MFA challenge token.")

        account = self.admin_repo.get_by_id(payload["admin_id"])
        if account is None or not account.mfa_enrolled or not account.mfa_secret:
            raise MfaNotEnrolledError(f"Admin '{payload.get('admin_id')}' has no active MFA enrollment.")

        if not verify_totp(account.mfa_secret, totp_code):
            self._register_failed_attempt(account)
            raise InvalidMfaCodeError("Invalid TOTP code.")

        account.failed_login_count = 0
        account.locked_until = None
        account.last_login_at = datetime.now(timezone.utc)
        self.admin_repo.save(account)
        return self._issue_tokens(account)

    def enroll_mfa_start(self, admin_id: str) -> str:
        """Generates and stores a NEW MFA secret, but does NOT mark
        mfa_enrolled=True yet -- that only happens after the admin proves
        possession via confirm_mfa_enrollment(). Returns the base32 secret
        (the caller/router turns this into a QR-code otpauth:// URI)."""
        account = self.admin_repo.get_by_id(admin_id)
        if account is None:
            raise ValueError(f"No admin found with id {admin_id}")
        secret = generate_secret()
        account.mfa_secret = secret
        account.mfa_enrolled = False
        self.admin_repo.save(account)
        return secret

    def confirm_mfa_enrollment(self, admin_id: str, totp_code: str) -> bool:
        """Verifies the admin's authenticator app is correctly configured
        before activating MFA. Returns True and sets mfa_enrolled=True on
        success; raises InvalidMfaCodeError on a wrong code (enrollment
        stays inactive)."""
        account = self.admin_repo.get_by_id(admin_id)
        if account is None or not account.mfa_secret:
            raise MfaNotEnrolledError(f"No pending MFA enrollment for admin '{admin_id}'.")
        if not verify_totp(account.mfa_secret, totp_code):
            raise InvalidMfaCodeError("Invalid TOTP code -- enrollment not activated.")
        account.mfa_enrolled = True
        self.admin_repo.save(account)
        return True

    # -- Refresh token (rotation on every use, per Business Owner directive) --

    def refresh_access_token(self, refresh_token_id: str) -> LoginResult:
        record = self.refresh_token_repo.get_by_id(refresh_token_id)
        now = datetime.now(timezone.utc)
        if record is None or record.revoked or record.expires_at <= now:
            raise RefreshTokenInvalidError("Refresh token is unknown, revoked, or expired.")

        account = self.admin_repo.get_by_id(record.admin_id)
        if account is None or account.status != "ACTIVE":
            raise RefreshTokenInvalidError("Associated admin account is no longer active.")

        # Rotation: the OLD token is revoked immediately and permanently
        # linked to its replacement (for audit purposes) -- it can never
        # be used again, even if the caller tries to reuse it (replay
        # protection: single-use refresh tokens).
        new_result = self._issue_tokens(account)
        record.revoked = True
        record.replaced_by_token_id = new_result.refresh_token_id
        self.refresh_token_repo.save(record)
        return new_result

    def revoke_refresh_token(self, refresh_token_id: str) -> None:
        self.refresh_token_repo.revoke(refresh_token_id)

    def revoke_all_sessions(self, admin_id: str) -> None:
        self.refresh_token_repo.revoke_all_for_admin(admin_id)

    # -- Internal -----------------------------------------------------------

    def _issue_tokens(self, account: AdminAccount) -> LoginResult:
        identity = AdminIdentity(admin_id=account.id, role_id=account.role_id, email=account.email)
        access_token = jwt_encode(
            {
                "admin_id": identity.admin_id, "role_id": identity.role_id, "email": identity.email,
                # Unique per issuance (not just per-admin) -- standard JWT
                # practice for traceability, and ensures two tokens issued
                # in the same second for the same admin are never
                # byte-identical (relevant for audit-log correlation later).
                "jti": str(uuid.uuid4()),
            },
            self.config.jwt_secret, expires_in_seconds=self.config.access_token_ttl_seconds,
        )
        now = datetime.now(timezone.utc)
        refresh_record = RefreshTokenRecord(
            token_id=str(uuid.uuid4()), admin_id=account.id, issued_at=now,
            expires_at=now + timedelta(seconds=self.config.refresh_token_ttl_seconds),
        )
        self.refresh_token_repo.save(refresh_record)
        return LoginResult(identity=identity, access_token=access_token, refresh_token_id=refresh_record.token_id)

    def get_identity_from_access_token(self, access_token: str) -> AdminIdentity:
        """Verifies an access token and extracts AdminIdentity -- this is
        the exact extraction point a future RBAC dependency/middleware
        will call. Raises InvalidTokenError for any invalid/expired token."""
        payload = jwt_decode(access_token, self.config.jwt_secret)
        return AdminIdentity(admin_id=payload["admin_id"], role_id=payload["role_id"], email=payload["email"])
