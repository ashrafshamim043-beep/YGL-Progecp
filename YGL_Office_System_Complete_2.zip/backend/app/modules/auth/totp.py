"""
TOTP (Time-based One-Time Password) -- RFC 6238, built on HOTP -- RFC 4226.

DESIGN NOTE (flagged): pyotp is declared in pyproject.toml as the intended
production library, but cannot be installed in this offline sandbox. This
module implements RFC 6238/4226 directly against the Python standard
library (hmac, hashlib, struct, base64, time) -- a real, spec-compliant
implementation, not a mock. It is interchangeable with pyotp's behavior
for standard 6-digit/30-second TOTP (the universal default used by Google
Authenticator, Authy, etc.), so swapping to pyotp later (if desired) is a
drop-in replacement, not a redesign.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import os
import struct
import time

TOTP_DIGITS = 6
TOTP_PERIOD_SECONDS = 30
TOTP_ALGO = hashlib.sha1  # RFC 6238 default; matches Google Authenticator/Authy compatibility


def generate_secret(length_bytes: int = 20) -> str:
    """Returns a base32-encoded random secret (RFC 4226 recommends >= 128 bits;
    20 bytes = 160 bits, matching common authenticator-app expectations)."""
    return base64.b32encode(os.urandom(length_bytes)).decode("ascii")


def _hotp(secret_b32: str, counter: int) -> str:
    """RFC 4226 HOTP algorithm with standard dynamic truncation."""
    key = base64.b32decode(secret_b32.upper())
    counter_bytes = struct.pack(">Q", counter)
    digest = hmac.new(key, counter_bytes, TOTP_ALGO).digest()
    offset = digest[-1] & 0x0F
    truncated = digest[offset:offset + 4]
    code_int = struct.unpack(">I", truncated)[0] & 0x7FFFFFFF
    return str(code_int % (10 ** TOTP_DIGITS)).zfill(TOTP_DIGITS)


def generate_totp(secret_b32: str, at_time: float | None = None) -> str:
    t = at_time if at_time is not None else time.time()
    counter = int(t // TOTP_PERIOD_SECONDS)
    return _hotp(secret_b32, counter)


def verify_totp(secret_b32: str, code: str, at_time: float | None = None, window: int = 1) -> bool:
    """
    Verifies a submitted TOTP code, allowing +/- `window` time-steps of
    clock drift (RFC 6238 explicitly recommends a small validation window
    -- 1 step = +/-30s here, the common default). Constant-time comparison
    per candidate to avoid timing side-channels.
    """
    if not code or not code.isdigit() or len(code) != TOTP_DIGITS:
        return False
    t = at_time if at_time is not None else time.time()
    base_counter = int(t // TOTP_PERIOD_SECONDS)
    for offset in range(-window, window + 1):
        candidate = _hotp(secret_b32, base_counter + offset)
        if hmac.compare_digest(candidate, code):
            return True
    return False
