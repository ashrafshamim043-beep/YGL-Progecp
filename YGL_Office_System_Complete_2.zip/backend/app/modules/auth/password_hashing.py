"""
Password hashing.

DESIGN NOTE (flagged, not silently substituted): the Recommended Technical
Stack document specified Argon2id (via argon2-cffi) as the production
password-hashing algorithm. This sandbox has no network access, so
argon2-cffi cannot be installed/tested here. This module instead
implements PBKDF2-HMAC-SHA256 using ONLY the Python standard library
(hashlib.pbkdf2_hmac) -- a real, NIST-recommended (SP 800-132), widely
production-used password KDF (e.g. it was Django's default for years) --
so that Auth has a genuinely secure, immediately testable implementation
now, with zero fake/mocked crypto.

TECHNICAL LEAD DECISION REQUIRED: keep PBKDF2-HMAC-SHA256 (already secure,
zero extra dependency), or install argon2-cffi in the real deployment
environment and swap PasswordHasher's implementation (interface below is
designed so that swap touches only this one file).

Never stores or logs a plaintext password anywhere, at any point.
"""
from __future__ import annotations

import hashlib
import hmac
import os
import base64
from dataclasses import dataclass

# NIST SP 800-132 recommends >= 10,000 iterations for PBKDF2-HMAC-SHA256;
# OWASP's 2023 guidance recommends >= 600,000 for SHA256. We use OWASP's
# stronger figure. TECHNICAL LEAD DECISION: tune for real server capacity
# during load testing (Phase 8.2 plan Section G already flagged this).
DEFAULT_ITERATIONS = 600_000
SALT_BYTES = 16
HASH_ALGO = "sha256"


class InvalidHashFormatError(Exception):
    """Raised when a stored hash string cannot be parsed (corrupted data,
    or a hash produced by a different scheme than this module expects)."""


@dataclass(frozen=True)
class PasswordHasher:
    iterations: int = DEFAULT_ITERATIONS

    def hash_password(self, plaintext_password: str) -> str:
        """Returns an encoded string: 'pbkdf2_sha256$<iterations>$<salt_b64>$<hash_b64>'
        -- self-describing so iteration count can be increased later without
        breaking verification of older hashes (a standard, safe pattern)."""
        if not plaintext_password:
            raise ValueError("Password must not be empty.")
        salt = os.urandom(SALT_BYTES)
        derived = hashlib.pbkdf2_hmac(HASH_ALGO, plaintext_password.encode("utf-8"), salt, self.iterations)
        return (
            f"pbkdf2_sha256${self.iterations}$"
            f"{base64.b64encode(salt).decode('ascii')}$"
            f"{base64.b64encode(derived).decode('ascii')}"
        )

    def verify_password(self, plaintext_password: str, stored_hash: str) -> bool:
        """Constant-time verification. Returns False (never raises) for a
        wrong password; raises InvalidHashFormatError only for a
        structurally corrupt stored_hash (a data-integrity problem, not a
        wrong-password case -- callers must not conflate the two)."""
        try:
            scheme, iterations_str, salt_b64, hash_b64 = stored_hash.split("$")
        except ValueError:
            raise InvalidHashFormatError(f"Malformed stored hash: {stored_hash!r}")
        if scheme != "pbkdf2_sha256":
            raise InvalidHashFormatError(f"Unrecognized hash scheme: {scheme!r}")
        try:
            iterations = int(iterations_str)
            salt = base64.b64decode(salt_b64)
            expected = base64.b64decode(hash_b64)
        except (ValueError, base64.binascii.Error) as e:
            raise InvalidHashFormatError(f"Malformed stored hash components: {e}")

        actual = hashlib.pbkdf2_hmac(HASH_ALGO, plaintext_password.encode("utf-8"), salt, iterations)
        return hmac.compare_digest(actual, expected)
