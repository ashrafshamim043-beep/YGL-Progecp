"""
Auth core domain logic. Pure Python (no FastAPI/SQLAlchemy import here) --
same pattern as app/modules/kyc/core.py: abstract repository interfaces +
in-memory implementations for tests, DB-backed adapters plugged in
separately for production.

Scope boundary (per this step's explicit authorization): Admin
authentication only. Member authentication, RBAC permission-checking
middleware, and the audit_logs DB adapter are explicitly OUT of scope for
this step -- see this module's admin_identity output, which is designed
to be consumed by a LATER RBAC/audit layer, not implemented here.
"""
from __future__ import annotations

import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional, Dict, List

from app.modules.auth.password_hashing import PasswordHasher, InvalidHashFormatError
from app.modules.auth.totp import generate_secret, generate_totp, verify_totp
from app.modules.auth.jwt_utils import encode as jwt_encode, decode as jwt_decode, InvalidTokenError


# ---------------------------------------------------------------------------
# Domain records
# ---------------------------------------------------------------------------

@dataclass
class AdminAccount:
    id: str
    email: str
    password_hash: str
    role_id: str
    status: str  # "ACTIVE" / "DISABLED"
    mfa_secret: Optional[str] = None
    mfa_enrolled: bool = False
    failed_login_count: int = 0
    locked_until: Optional[datetime] = None
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    last_login_at: Optional[datetime] = None


@dataclass(frozen=True)
class AdminIdentity:
    """The output of a successful authentication -- deliberately minimal
    and provider-agnostic, designed to be exactly what a FUTURE RBAC
    middleware and audit-log writer will consume (per this step's
    authorization: 'Admin identity extraction যাতে পরবর্তী RBAC এবং audit
    layer ব্যবহার করতে পারে'). No RBAC/audit code is implemented here."""
    admin_id: str
    role_id: str
    email: str


@dataclass
class RefreshTokenRecord:
    token_id: str
    admin_id: str
    issued_at: datetime
    expires_at: datetime
    revoked: bool = False
    replaced_by_token_id: Optional[str] = None  # set on rotation, for audit-trail purposes


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class InvalidCredentialsError(Exception):
    """Raised for wrong password OR unknown email -- deliberately the SAME
    exception/message for both cases (never reveals whether an email
    exists), per standard authentication security practice."""


class AccountLockedError(Exception):
    def __init__(self, locked_until: datetime):
        self.locked_until = locked_until
        super().__init__(f"Account is locked until {locked_until.isoformat()}.")


class AccountDisabledError(Exception):
    pass


class MfaRequiredError(Exception):
    """Raised when password verification succeeds but MFA has not yet been
    completed for this login attempt -- the caller must present a TOTP
    challenge next; no session/token is issued at this point."""
    def __init__(self, admin_id: str, mfa_challenge_token: str):
        self.admin_id = admin_id
        self.mfa_challenge_token = mfa_challenge_token
        super().__init__("MFA verification required to complete login.")


class InvalidMfaCodeError(Exception):
    pass


class MfaNotEnrolledError(Exception):
    pass


class RefreshTokenInvalidError(Exception):
    """Raised for an unknown, expired, or already-revoked refresh token."""


# ---------------------------------------------------------------------------
# Repository interfaces
# ---------------------------------------------------------------------------

class AdminRepository(ABC):
    @abstractmethod
    def get_by_email(self, email: str) -> Optional[AdminAccount]:
        raise NotImplementedError

    @abstractmethod
    def get_by_id(self, admin_id: str) -> Optional[AdminAccount]:
        raise NotImplementedError

    @abstractmethod
    def save(self, account: AdminAccount) -> None:
        raise NotImplementedError


class RefreshTokenRepository(ABC):
    @abstractmethod
    def save(self, record: RefreshTokenRecord) -> None:
        raise NotImplementedError

    @abstractmethod
    def get_by_id(self, token_id: str) -> Optional[RefreshTokenRecord]:
        raise NotImplementedError

    @abstractmethod
    def revoke(self, token_id: str) -> None:
        raise NotImplementedError

    @abstractmethod
    def revoke_all_for_admin(self, admin_id: str) -> None:
        """Used for 'log out everywhere' / a suspected-compromise response."""
        raise NotImplementedError


# ---------------------------------------------------------------------------
# In-memory implementations (testing)
# ---------------------------------------------------------------------------

class InMemoryAdminRepository(AdminRepository):
    def __init__(self):
        self._by_id: Dict[str, AdminAccount] = {}

    def get_by_email(self, email: str) -> Optional[AdminAccount]:
        for acc in self._by_id.values():
            if acc.email == email:
                return acc
        return None

    def get_by_id(self, admin_id: str) -> Optional[AdminAccount]:
        return self._by_id.get(admin_id)

    def save(self, account: AdminAccount) -> None:
        self._by_id[account.id] = account


class InMemoryRefreshTokenRepository(RefreshTokenRepository):
    def __init__(self):
        self._by_id: Dict[str, RefreshTokenRecord] = {}

    def save(self, record: RefreshTokenRecord) -> None:
        self._by_id[record.token_id] = record

    def get_by_id(self, token_id: str) -> Optional[RefreshTokenRecord]:
        return self._by_id.get(token_id)

    def revoke(self, token_id: str) -> None:
        rec = self._by_id.get(token_id)
        if rec is not None:
            rec.revoked = True

    def revoke_all_for_admin(self, admin_id: str) -> None:
        for rec in self._by_id.values():
            if rec.admin_id == admin_id:
                rec.revoked = True
