"""
Member Lifecycle models — members, KYC documents, member status history.

member_status_history is the real, persistent backing for the Commission
Engine's MemberStatusHistoryProvider interface (see genealogy.py). It is
append-only: a status change writes a NEW row with effective_from set to
now and closes the previous row's effective_to -- it never UPDATEs an
existing status value in place.
"""
import uuid
from datetime import datetime

from sqlalchemy import String, DateTime, ForeignKey, Text, func
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.session import Base


class Member(Base):
    __tablename__ = "members"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    full_name: Mapped[str] = mapped_column(String(255), nullable=False)
    email: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    phone: Mapped[str | None] = mapped_column(String(32))
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    # Mirrors commission_engine.models.AccountStatus exactly (ACTIVE / SUSPENDED / TERMINATED).
    # This column always reflects CURRENT status; historical values live in
    # member_status_history, which is what Commission Engine actually reads
    # for point-in-time-correct calculations.
    account_status: Mapped[str] = mapped_column(String(32), default="ACTIVE", nullable=False)
    # Mirrors commission_engine.genealogy.MemberRole (CUSTOMER / MEMBER / STAFF).
    role: Mapped[str] = mapped_column(String(32), default="MEMBER", nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class MemberStatusHistory(Base):
    __tablename__ = "member_status_history"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    member_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("members.id"), nullable=False)
    account_status: Mapped[str] = mapped_column(String(32), nullable=False)
    effective_from: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    effective_to: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))  # NULL = still current
    changed_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("admins.id"))


class KycDocument(Base):
    __tablename__ = "kyc_documents"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    member_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("members.id"), nullable=False)
    document_type: Mapped[str] = mapped_column(String(64), nullable=False)
    file_reference: Mapped[str] = mapped_column(Text, nullable=False)  # encrypted object-storage pointer
    status: Mapped[str] = mapped_column(String(32), default="PENDING", nullable=False)  # PENDING/APPROVED/REJECTED
    reviewed_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("admins.id"))
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    rejection_reason: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
