"""
KYC API router. Wires HTTP requests to YGLKYCService -- contains NO
business logic itself (state-machine rules, activation conditions, etc.
all live in service.py/core.py).
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.core.config import settings
from app.db.session import get_db
from app.modules.kyc.core import DuplicateApplicantError, KYCState
from app.modules.kyc.service import YGLKYCService
from app.modules.kyc.sumsub_adapter import SumsubAdapter
from app.modules.kyc.db_repositories import (
    SQLAlchemyKYCVerificationRepository, SQLAlchemyKYCStateTransitionRepository,
)
from app.modules.kyc.member_activation_adapter import SQLAlchemyMemberActivationPort
from app.modules.audit.db_repository import SQLAlchemyAuditLogWriter
from app.modules.rbac.core import Permission
from app.modules.rbac.dependencies import require_permission

router = APIRouter()


def get_kyc_service(db: Session = Depends(get_db)) -> YGLKYCService:
    """
    Fully wired: SumsubAdapter (webhook verification/parsing only -- live
    API calls still blocked, see sumsub_adapter.py), DB-backed verification
    + state-transition repositories, DB-backed audit log, and the
    transactional member-activation port. No NotImplementedError remains
    here.
    """
    provider = SumsubAdapter(webhook_secret=settings.sumsub_webhook_secret)
    verification_repo = SQLAlchemyKYCVerificationRepository(db)
    transition_repo = SQLAlchemyKYCStateTransitionRepository(db)
    audit_log = SQLAlchemyAuditLogWriter(db)
    member_activation = SQLAlchemyMemberActivationPort(db)
    return YGLKYCService(provider, verification_repo, transition_repo, audit_log, member_activation)


@router.post("/webhooks/sumsub")
async def receive_sumsub_webhook(
    request: Request,
    kyc_service: YGLKYCService = Depends(get_kyc_service),
):
    """
    Receives Sumsub's applicantReviewed webhooks. Signature verification
    happens FIRST, inside kyc_service.process_webhook() -- this endpoint
    does no pre-processing of the payload itself.
    """
    raw_body = await request.body()
    signature_header = request.headers.get("X-Payload-Digest", "")
    result = kyc_service.process_webhook(raw_body, signature_header)
    return {"accepted": result.accepted, "reason": result.reason}


@router.post("/members/{member_id}/kyc/start")
async def start_kyc_verification(
    member_id: str,
    kyc_service: YGLKYCService = Depends(get_kyc_service),
):
    """
    Starts a new KYC verification for a member. Does NOT call
    provider.create_applicant() (that requires live Sumsub credentials,
    still blocked -- Production Vendor Approval PENDING). This endpoint
    remains 503 until that approval is granted; the DuplicateApplicantError
    path is real and tested (see test_kyc_pipeline.py), it simply cannot
    be reached via this HTTP path yet because applicant creation itself
    is blocked upstream.
    """
    raise HTTPException(
        status_code=503,
        detail="KYC verification start requires live Sumsub credentials, "
               "which are not yet authorized (Production Vendor Approval PENDING).",
    )


class ManualReviewDecisionRequest(BaseModel):
    reason: str | None = None  # optional reviewer notes, per Business Owner directive


@router.post("/kyc/{verification_id}/manual-review/approve")
async def approve_manual_review(
    verification_id: str,
    body: ManualReviewDecisionRequest,
    kyc_service: YGLKYCService = Depends(get_kyc_service),
    identity=Depends(require_permission(Permission.KYC_REVIEW)),
):
    """
    Compliance/KYC Admin (or Super Admin, per the Business Owner's role
    matrix -- both hold kyc.review) resolves a MANUAL_REVIEW verification
    as APPROVED.

    - Authorization: enforced by require_permission(Permission.KYC_REVIEW)
      -- 401/403 handled entirely by that dependency, before this function
      body ever runs.
    - Valid state transition: enforced inside
      YGLKYCService.resolve_manual_review() (state-machine, unmodified).
    - Reviewer identity: `identity.admin_id`, passed through to the
      service so it lands in the state-transition record's actor_id.
    - Idempotency: resolve_manual_review() checks
      `verification.state != MANUAL_REVIEW` and returns a non-accepted
      result (not an error, not a silent no-op) if this verification has
      already been resolved -- calling approve twice does not double-apply.
    """
    result = kyc_service.resolve_manual_review(verification_id, admin_id=identity.admin_id, approve=True)
    if not result.accepted:
        raise HTTPException(status_code=409, detail=f"Cannot approve: {result.reason}")
    return {
        "verification_id": result.verification_id, "new_state": result.new_state.value,
        "member_activated": result.member_activated,
    }


@router.post("/kyc/{verification_id}/manual-review/reject")
async def reject_manual_review(
    verification_id: str,
    body: ManualReviewDecisionRequest,
    kyc_service: YGLKYCService = Depends(get_kyc_service),
    identity=Depends(require_permission(Permission.KYC_REVIEW)),
):
    """Compliance/KYC Admin resolves a MANUAL_REVIEW verification as
    REJECTED. Same authorization/state-transition/idempotency guarantees
    as approve_manual_review() above."""
    result = kyc_service.resolve_manual_review(verification_id, admin_id=identity.admin_id, approve=False)
    if not result.accepted:
        raise HTTPException(status_code=409, detail=f"Cannot reject: {result.reason}")
    return {"verification_id": result.verification_id, "new_state": result.new_state.value}
