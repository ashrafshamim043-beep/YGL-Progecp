"""
SQLAlchemyMemberActivationPort -- implements kyc.core.MemberActivationPort.

Per the Business Owner's transactional-integrity directive (Phase 8.2
consolidation): member status ACTIVE + member_status_history row + audit
record are written inside ONE database transaction. If anything fails,
nothing commits -- the caller (YGLKYCService.try_activate_member) already
treats a False return as "nothing happened", so this adapter's job is
simply to make that literally true at the DB level.
"""
import uuid
from datetime import datetime, timezone

from sqlalchemy.orm import Session

from app.modules.kyc.core import MemberActivationPort
from app.modules.member.db_models import Member, MemberStatusHistory
from app.modules.audit.db_repository import AuditLogRow


class SQLAlchemyMemberActivationPort(MemberActivationPort):
    def __init__(self, db: Session):
        self.db = db

    def activate_member_transactionally(
        self, member_id: str, kyc_verification_id: str, admin_or_system_actor: str
    ) -> bool:
        try:
            member = self.db.get(Member, uuid.UUID(member_id))
            if member is None:
                return False

            now = datetime.now(timezone.utc)
            member.account_status = "ACTIVE"

            self.db.add(MemberStatusHistory(
                id=uuid.uuid4(), member_id=member.id, account_status="ACTIVE",
                effective_from=now, effective_to=None,
                changed_by=None,  # system-driven (KYC approval), not a specific admin's manual status change
            ))
            self.db.add(AuditLogRow(
                id=uuid.uuid4(), event_type="MEMBER_ACTIVATED",
                actor_id=admin_or_system_actor, actor_type="SYSTEM",
                action="ACTIVATE_MEMBER", target_entity="member", target_id=member_id,
                result="SUCCESS",
                payload={"member_id": member_id, "kyc_verification_id": kyc_verification_id},
            ))
            self.db.flush()
            self.db.commit()
            return True
        except Exception:
            # Any failure (constraint violation, connection issue, etc.) --
            # roll back everything in this transaction, nothing partially
            # applies. The caller must treat this as "activation did not
            # happen" and may retry later; it must never assume partial
            # success.
            self.db.rollback()
            return False
