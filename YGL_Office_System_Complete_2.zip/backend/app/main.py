"""
Y.G.L Office System -- FastAPI application entrypoint.

Routers wired: Auth (login/MFA/refresh) and KYC (webhook + manual-review,
RBAC-protected). Member/Sponsor/Genealogy/Commerce routers remain
unwired -- those modules have DB models (Phase 8.1) but no service/router
layer yet; wiring an endpoint before its database, authorization, and
error handling are complete is explicitly against this step's directive.

Per the architecture boundary rule, this file and every module under
app/modules/ must NEVER import commission_engine directly. Only
app/services/commission_service/ may do so (enforced by
scripts/verify_import_boundary.py in CI).
"""
from fastapi import FastAPI

from app.core.config import settings
from app.modules.auth.router import router as auth_router
from app.modules.kyc.router import router as kyc_router

app = FastAPI(
    title=settings.app_name,
    version="0.2.0",
    description="Y.G.L (Your Global Link) — Office System API. "
                 "Phase 8.2: Auth/MFA, RBAC, KYC wired. Member/Sponsor/Commerce pending.",
)


@app.get("/health")
async def health_check() -> dict:
    """Basic liveness check. Does not touch the database."""
    return {"status": "ok", "service": settings.app_name, "environment": settings.environment}


app.include_router(auth_router, prefix=settings.api_v1_prefix, tags=["auth"])
app.include_router(kyc_router, prefix=settings.api_v1_prefix, tags=["kyc"])

# --- NOT YET WIRED (remaining blockers, see Final Report) -------------------
# from app.modules.member.router import router as member_router
# from app.modules.sponsor.router import router as sponsor_router
# app.include_router(member_router, prefix=f"{settings.api_v1_prefix}/members", tags=["members"])
# app.include_router(sponsor_router, prefix=f"{settings.api_v1_prefix}/sponsor", tags=["sponsor"])
# Neither module has a service/router layer yet -- only Phase 8.1 DB models.
